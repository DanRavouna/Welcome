import sys
OUT=sys.argv[1] if len(sys.argv)>1 else '/mnt/user-data/outputs/critter-roll-world.html'
W='/tmp/cr/world/'
h=open(W+'shell.html').read()
js='\n'.join(open(f'{W}{p}.js').read() for p in ['runtime','pixel','pxworld','world','cloud','music','app'])+'\n'
h=h.replace('/*@@JS@@*/',js,1).replace('<!--@@SCREEN@@-->',open(W+'screen.html').read(),1)
open(OUT,'w').write(h); print('built',OUT,len(h)//1024,'KB')
